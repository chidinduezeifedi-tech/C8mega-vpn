package com.c8mega.vpn;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int PICK_CONFIG = 41;
    private static final int VPN_PERMISSION = 42;
    private GoBackend backend;
    private Config config;
    private String tunnelName = "C8Mega";
    private TextView status, serverLabel, help;
    private Button connectButton;

    private final Tunnel tunnel = new Tunnel() {
        @Override public String getName() { return tunnelName; }
        @Override public void onStateChange(State state) {
            runOnUiThread(() -> showState(state));
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        backend = new GoBackend(this);
        buildScreen();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(8, 13, 25));
        LinearLayout root = new LinearLayout(this);
        root.setPadding(dp(24), dp(34), dp(24), dp(24));
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root);

        TextView brand = text("C8MEGA VPN", 28, Color.WHITE, true);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand, matchWrap());
        TextView subtitle = text("PRIVATE CONNECTION • WIREGUARD", 11, Color.rgb(140, 165, 210), true);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, matchWrap());
        addSpace(root, 42);

        TextView globe = text("◎", 76, Color.rgb(91, 140, 255), true);
        globe.setGravity(Gravity.CENTER);
        root.addView(globe, matchWrap());
        status = text("DISCONNECTED", 19, Color.rgb(255, 190, 80), true);
        status.setGravity(Gravity.CENTER);
        root.addView(status, matchWrap());
        addSpace(root, 24);

        connectButton = button("CONNECT", true);
        connectButton.setOnClickListener(v -> toggleVpn());
        root.addView(connectButton, matchWidth());
        addSpace(root, 14);
        Button importButton = button("IMPORT WIREGUARD CONFIG (.CONF)", false);
        importButton.setOnClickListener(v -> chooseConfig());
        root.addView(importButton, matchWidth());
        addSpace(root, 22);

        serverLabel = text("No server configuration imported", 15, Color.WHITE, true);
        serverLabel.setGravity(Gravity.CENTER);
        root.addView(serverLabel, matchWrap());
        addSpace(root, 12);
        help = text("Import a .conf file from a VPN provider. The country you appear to be in is determined by that server's location. C8Mega VPN does not include free servers by itself.", 13, Color.rgb(180, 190, 210), false);
        help.setGravity(Gravity.CENTER);
        root.addView(help, matchWrap());
        addSpace(root, 28);
        TextView footer = text("Your VPN traffic is handled by the WireGuard tunnel engine. Only import configurations from providers you trust.", 11, Color.rgb(120, 135, 160), false);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, matchWrap());
        setContentView(scroll);
    }

    private void chooseConfig() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, PICK_CONFIG);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_CONFIG && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            try (InputStream in = getContentResolver().openInputStream(uri);
                 BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                config = Config.parse(reader);
                String fileName = uri.getLastPathSegment();
                tunnelName = "C8Mega";
                serverLabel.setText("Configuration loaded: " + (fileName == null ? "WireGuard server" : fileName));
                status.setText("READY TO CONNECT");
                status.setTextColor(Color.rgb(90, 210, 150));
                Toast.makeText(this, "WireGuard configuration imported", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                config = null;
                Toast.makeText(this, "Could not read this config. Choose a valid WireGuard .conf file.", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == VPN_PERMISSION && resultCode == RESULT_OK) {
            startTunnel();
        } else if (requestCode == VPN_PERMISSION) {
            Toast.makeText(this, "VPN permission was not granted", Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleVpn() {
        if (config == null) {
            Toast.makeText(this, "Import a WireGuard .conf file first", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            if (backend.getState(tunnel) == Tunnel.State.UP) {
                backend.setState(tunnel, Tunnel.State.DOWN, null);
            } else {
                Intent intent = GoBackend.VpnService.prepare(this);
                if (intent != null) startActivityForResult(intent, VPN_PERMISSION);
                else startTunnel();
            }
        } catch (Exception e) {
            Toast.makeText(this, "VPN error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void startTunnel() {
        try {
            backend.setState(tunnel, Tunnel.State.UP, config);
            showState(Tunnel.State.UP);
        } catch (Exception e) {
            Toast.makeText(this, "Could not start VPN: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showState(Tunnel.State state) {
        boolean up = state == Tunnel.State.UP;
        status.setText(up ? "CONNECTED" : "DISCONNECTED");
        status.setTextColor(up ? Color.rgb(80, 220, 150) : Color.rgb(255, 190, 80));
        connectButton.setText(up ? "DISCONNECT" : "CONNECT");
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(0, dp(5), 0, dp(5)); return t;
    }
    private Button button(String label, boolean primary) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(15);
        b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(primary ? Color.rgb(49, 103, 220) : Color.rgb(30, 43, 67)));
        return b;
    }
    private void addSpace(LinearLayout root, int h) { View v = new View(this); root.addView(v, new LinearLayout.LayoutParams(1, dp(h))); }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private LinearLayout.LayoutParams matchWidth() { return new LinearLayout.LayoutParams(-1, dp(54)); }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
