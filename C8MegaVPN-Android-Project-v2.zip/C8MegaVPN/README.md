# C8Mega VPN (Android starter project)

A small Android WireGuard client shell branded C8Mega VPN. It imports a WireGuard `.conf` file and uses the official WireGuard tunnel library to start/stop the tunnel.

## Important limitations
- This app does **not** include VPN servers. You must obtain a valid WireGuard configuration from a VPN provider or operate your own server.
- A server's country determines the apparent IP location. The country picker/server directory is not included because there are no verified free server endpoints bundled here.
- Do not use random configuration files from untrusted sources. A VPN provider can potentially observe metadata about your traffic.
- This is a starter build, not a security-audited commercial VPN product.

## Build APK with GitHub Actions
1. Create a GitHub account and a new empty repository named `C8MegaVPN`.
2. Upload the contents of this folder to the repository (not the folder wrapper itself).
3. Open the repository's **Actions** tab.
4. Select **Build C8Mega VPN APK**, then **Run workflow** (or wait for the first push build).
5. Open the completed workflow run and download the `C8MegaVPN-debug-apk` artifact.
6. Extract the ZIP on your Android phone and install `app-debug.apk`. Android may ask you to allow installation from your browser/file manager.

The GitHub build uses Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3, and the official WireGuard tunnel library from Maven Central.
